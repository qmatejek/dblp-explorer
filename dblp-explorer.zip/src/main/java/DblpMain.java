import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.*;



public class DblpMain
{
    public static void main(String[] Args) throws IOException {

        float start = System.currentTimeMillis();

        float startMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();

        Scanner scan = new Scanner(System.in);

        String testFile = new File("").getAbsolutePath();

        System.out.println("This is testFile: " + testFile);


        System.out.print("Please enter the name of the json file: ");
        String fileName = scan.nextLine();

//        File jsonFile = new File("src\\main\\resources\\dblp_papers_v11.txt");

        File jsonFile = new File("src\\main\\resources\\" + fileName);

        //Making sure the file exists
        if(!jsonFile.exists())
        {
            System.out.println("There was wan error with file. Please restart program and make sure you enter a valid test file name");
            System.exit(0);
        }



        BufferedReader reader = new BufferedReader(new FileReader(jsonFile)); //Needed to read json file


        Scanner scan2 = new Scanner(System.in); // get keyword and integer n.

        System.out.print("Please enter keyword: ");
        String keyword = scan2.nextLine();
        System.out.print("Please enter your n (integer): ");
        int n = scan2.nextInt();

        scan2.close();
        scan.close();


        ArrayList<String> list = new ArrayList<>(); //Holds the tier 1 papers
        ArrayList<String> refList = new ArrayList<>(); //Holds the tier 2-n papers

        System.out.println("=====================[Keyword Titles]===========================================================================");

        String line;
        while((line = reader.readLine()) != null)
        {

            ArrayList<String> tmpList = searchKey(line, keyword);

            if(!tmpList.isEmpty())
                list.addAll(tmpList);


        }
        System.out.println("================================================================================================================\n");
        System.out.println("Initial file processing done");

        reader.close();


        ArrayList<String> temp = new ArrayList<>();

        if(!list.isEmpty())
        {
            Collections.sort(list); //list must be sorted for use with getRefs
            temp = getRefs(list, jsonFile); //Tier 2 papers

        }
        else
            System.out.println("list was empty");


        refList.addAll(temp); // Add tier 2 papers to refList
        System.out.println("Tier 2 papers added to refList");

        //Should add tier 3 - tier n papers to refList
        for(int i = 2; i < n; i++)
        {
            Collections.sort(temp);
            temp = getRefs(temp, jsonFile);
            refList.addAll(temp);
        }


        System.out.println("Getting titles and id's...");

        if(!list.isEmpty()) //finding all the title id's that match the reference id's for tier 1 papers.
        {
            System.out.println("\n====================[Tier 1 papers (start)]==========================================================================\n");
            refSearch(list, jsonFile);
            System.out.println("\n====================[Tier 1 papers (end)]============================================================================");
        }
        else
            System.out.println("No tier 1 papers found");

        if(!refList.isEmpty()) //finding all the title id's that match the reference id's for tier 2-n papers.
        {
            System.out.println("\n====================[Tier 2-n papers (start)]========================================================================\n");
            Collections.sort(refList);
            refSearch(refList, jsonFile);
            System.out.println("\n====================[Tier 2-n papers (end)]========================================================================");
        }
        else
            System.out.println("No papers from tiers 2 through n were found");

        float endMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        float end = System.currentTimeMillis();

        float totalMemUsed = endMem - startMem; //This is the memory usage of the program.
        float totalMemUsedKB = totalMemUsed / 1024.0f;

        System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("Total memory used (bytes): " + totalMemUsed);
        System.out.println("Total memory used (KB): " + totalMemUsedKB);

        float totalTime = end - start; //This is the runtime of the program.
        System.out.println("Total run time in ms: " + totalTime);
        System.out.println("Total run time in seconds: " + (totalTime/1000.0f) );
        System.out.println("Total run time in minutes: " + ((totalTime/1000.0f) / 60.0f) );
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

    }
//===============================================[METHODS]==============================================================

    //This takes in a line from the json file to parse. It then searches that line of the file to see if the keyword
    //passed to it shows up in the title. If it does it returns the list of references for that paper.
    public static ArrayList<String> searchKey(String entry, String key) throws IOException
    {

        JsonFactory jsf = new JsonFactory();

        JsonParser parser = jsf.createParser(entry);

        boolean flag = false;

        String id = "";
        String title = "";
        ArrayList<String> list = new ArrayList<String>();

        while(parser.nextToken() != null)
        {
            String token = parser.getCurrentName();


            if("id".equals(token)) //Gets the id of the current paper
            {
                parser.nextToken();
                id = parser.getText();
            }


            if("title".equals(token)) //Checks the title of the current paper to see if it contains the keyword.
            {
                parser.nextToken();
                title = parser.getText();

                title = title.toLowerCase();
                key = key.toLowerCase();

                // If it does, set flag to true.
                if(title.contains(" " + key + " ") || title.contains(key + " ") || title.contains(" " + key + "."))
                {
                    flag = true;
                }
            }


            //Add the references of the current paper if the title contains the keyword.
            if("references".equals(token) && flag == true)
            {

                parser.nextToken();

                while(parser.nextToken() != JsonToken.END_ARRAY)
                {
                    list.add(parser.getText());
                }

                break;
            }




        }

        parser.close();

        if(flag) //If this title contained a keyword, then output it's title and id. Then return the list that contains its references.
        {
            System.out.println("title: " + title + "   id: " + id);
            return list;
        }

        return list;

    }
//======================================================================================================================

    //This takes in a line from the json file to parse. It then searches that line of the file to see if an id
    //passed to it shows up in the title. If it does it returns the list of references for that paper. Basically
    //same as the searchKey except with a paper ID instead of a keyword in a title.
    public static ArrayList<String> searchID(String entry, String id) throws IOException
    {
        JsonFactory jsf = new JsonFactory();

        JsonParser parser = jsf.createParser(entry);

        boolean flag = false;

        ArrayList<String> list = new ArrayList<String>();

        String title = "";

        while(parser.nextToken() != null)
        {
            String token = parser.getCurrentName();

            if("id".equals(token)) //Checks to see if id matches the id in the current line.
            {
                parser.nextToken();
                String ID = parser.getText();

                if(ID.contains(id))
                    flag = true;
            }

            if("title".equals(token) && flag)
            {
                parser.nextToken();
                title = parser.getText();
            }

            if("references".equals(token) && flag == true)//If it does, then return the references for this paper
            {
                parser.nextToken();

                while(parser.nextToken() != JsonToken.END_ARRAY)
                {
                    list.add(parser.getText());
                }

                break;
            }
        }

        parser.close();

        return list;

    }
//======================================================================================================================

    //This parses a line from the json file and checks if the id passed to it matches the id in the current line. If it
    //does, then it returns the title of the current json line.
    public static String getTitle(String entry, String id) throws IOException
    {
        JsonFactory jsf = new JsonFactory();

        JsonParser parser = jsf.createParser(entry);

        String title = "";
        boolean flag = false;

        while(parser.nextToken() != null)
        {
            String token = parser.getCurrentName();

            if("id".equals(token)) // Checks to see if the id in the current line matches the id passed to it
            {
                parser.nextToken();
                String ID = parser.getText();

                if(ID.contains(id))
                    flag = true;
            }

            if("title".equals(token) && flag) //If it did match, then we want this title
            {
                parser.nextToken();
                title = parser.getText();
                break;
            }

        }

        parser.close();

        return title; //return the title
    }
//======================================================================================================================

    //This takes in a list of reference id's, then used getTitle to get the title of each one, then adds it to the list,
    //which this method returns once it is finished getting all the titles.
    public static void refSearch(ArrayList<String> list, File file) throws IOException
    {
        BufferedReader reader = new BufferedReader(new FileReader(file));

        for(int i = 0; i < list.size(); i++)
        {
            String id = list.get(i);

            String line;
            while((line = reader.readLine()) != null)
            {
                String title = getTitle(line, id); //Get the title that matches the current id.

                if(title != "") //If a matching title is found.
                {
                    System.out.println("title: " + title +"   id: " + id); //print it and the id out.
                    break; //the title was found, no point in checking rest of file.
                }

            }

            //I did not restart the reader here, because that is not necessary as long as the list of reference id's
            //passed to it are sorted. This also assumes the id's in the file are in order, but they are in the v11
            //papers we were given, so...

        }

        reader.close();
    }
//======================================================================================================================

    //This method takes in a list of reference id's and adds the references of each one of those refs passed to it to a
    //list which it then returns once it is finished getting all the references.
    public static ArrayList<String> getRefs(ArrayList<String> list, File file) throws IOException
    {
        ArrayList<String> newList = new ArrayList<>();

        BufferedReader reader = new BufferedReader(new FileReader(file));


        boolean flag = false;

        String id = "";

        for(int i = 0; i < list.size(); i++)
        {
            id = list.get(i);


            String line;
            while((line = reader.readLine()) != null)
            {
                ArrayList<String> temp = searchID(line, id); //Get the references for the current id.


                if(!temp.isEmpty())
                {
                    newList.addAll(temp); //Add those references to the list
                    break;
                }

            }

            //I did not restart the reader here, because that is not necessary as long as the list of reference id's
            //passed to it are sorted. This also assumes the id's in the file are in order, but they are in the v11
            //papers we were given, so...

        }

        reader.close();

        return newList;
    }



}
