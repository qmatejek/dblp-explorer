Instructions:
=============
To run the program you should be able to do it pretty much the same way as my parking program. First cd to the target
directory, then run "java -jar dblp-explorer.jar" amd that should be it. This program should work on linux if my parking
one did. I handled file paths in pretty much the same way. I think you could copy the jar and the resources folder to the
desktop and tun the "java -jar dblp-explorer" on the desktop like last time, but it's probably safer to run it where it is.

If that doesn't work, you cam either try to cd to src\java\main where the parkingMain.java is and try to run it like normal
with cmd/terminal.
If that doesn't work, you may have to import the project into IntelliJ. If you do this you may have to setup a run configuration
that points to the directory where the .jar is (target).

Assumptions:
============
1.) A run time limit was not specified, so I assume we won't lose points if it takes longer than some unspecified time.
(Don't worry, it only took around an hour for the 12 gigabyte file)

2.) It says "keyword" not "keywords" so I assume the keyword is only a single word. My program may possibly work with a
phrase, but that's untested.

3.) It said we decide how to define importance and I chose to define it as the titles with id numbers in ascending order.
Tier 0, 1, and (2-n) are sorted separately. That is how I decided to do it.

4.) The professor said that BufferedReader counts for Stream, so that is what I used to read the file.

5.) For the part that says, "Use Maven to automate the build." I assumed that that meant to create the project as a Maven
project and create an ececutable jar.

6.) Professor said that tier 1 papers are the papers that were cited by the ones we found to contain the keyword in their
title, so I did that instead of what the assignment said because that was apparently a typo.

7.) I'm hoping the way I submitted it on github is okay since the assignment didn't say NOT to do it that way exactly.
Also I have been trying to upload it normally to github for the last 2-3 hours and it just won't let me.


Notes:
======
I will include a link to a shared google drive folder than contains some test cases I used that were too large for
github, but smaller than the 12 gig. They were made using the first so many lines from the 12 gig file.
This project was a lot to figure out in a week (since assignment 4 was due because I had to get that done before I worked
on this. Earliest Deadline First), so sorry if it seems at all rushed. In most other classes we would have been given
2-3 weeks for something like this. That being said, I believe I did get it done and working.

Here is that google drive link: https://drive.google.com/drive/folders/1ZJWOeGTy82HFjoEcMcfM5-gB9-jPunx7?usp=sharing
email me at: qmateak@yahoo.com if that doesn't work.

The runtime and memory usage printed at the end is correct for large enough files, but if the file is too small, like
Test1.txt, then the time and memory usage may be inaccurate.